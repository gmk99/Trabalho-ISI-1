Autores: Mário Macedo 
Numero: 25664
Turma: 3ano LESI

Ficheiros e funções:

Readme.md - Ficheiro pedidos com as descrições 
ISI 01.ktr - Transformação principal executada com um run
Job 1.kjd - Job principal executada com um run enviando um email

\automobile\Clientes
Carroseconomicoscliente1 - Lista de carros considerados com preços econômicos
cliente1 - Lista de carros dentro dos parâmetros do cliente 1
cliente1ordenado - Lista de carros dentro dos parâmetros do cliente 1 ordenados por preço

\automobile\CSV
auto - Ficheiro que contem a base de dados principal
faixapreco - Ficheiro que contem a base de dados para a definição dos econômicos

\automobile\Invalidações
inv_cavalos
inv_combustivel
inv_loc_motor
inv_portas
inv_preco_carros
inv_tracao
- Todos estes ficheiros são os automóveis que são retirados pelos filtros ou seja são dados como inválidos

